﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TCCprojeto.Libs.Login;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Controllers
{
    public class EmpresaController : Controller
    {
        private readonly IEmpresaRepository _empresaRepository;

        private readonly LoginUsuario _loginUsuario;

        public EmpresaController(IEmpresaRepository empresaRepository, LoginUsuario loginUsuario)
        {
            _empresaRepository = empresaRepository;
            _loginUsuario = loginUsuario;
        }

        [HttpGet]
        public IActionResult CadastrarEmpresa()
        {
            var user = _loginUsuario.GetUsuario();
            if(user == null)
            {
                return View();

            }
            else
            {
                return RedirectToAction("AtendimentosUsuario", "Atendimentos");
            }
        }

        [HttpPost]
        public IActionResult CadastrarEmpresa(Empresa empresa)
        {
            _empresaRepository.CadastrarEmpresa(empresa);
            return RedirectToAction("CadastroPrimeiroUsuario", "Usuario", empresa);
        }

        [HttpGet]
        public IActionResult EditarEmpresa(int? id)
        {
            var user = _loginUsuario.GetUsuario();
            if (user.IdTipoUsuario == 1)
            {
                var empresa = _empresaRepository.ObterEmpresa(id);
                return View(empresa);
            }
            if (user.IdTipoUsuario > 1)
            {
                return RedirectToAction("AtendimentosUsuario", "Atendimentos");
            }
            else
            {
                return RedirectToAction("Login", "Usuario");
            }
        }

        [HttpPost]
        public IActionResult EditarEmpresa([FromForm] Empresa empresa)
        {
            if (ModelState.IsValid)
            {
                _empresaRepository.AtualizarEmpresa(empresa);
            }
            return RedirectToAction("DetalhesEmpresa", empresa);
        }

        [HttpGet]
        public IActionResult DetalhesEmpresa(Empresa empresa)
        {
            var user = _loginUsuario.GetUsuario();
            if (user.IdTipoUsuario == 1)
            {
                return View(empresa);
            }
            if (user.IdTipoUsuario > 1)
            {
                return RedirectToAction("AtendimentosUsuario", "Atendimentos");
            }
            else
            {
                return RedirectToAction("Login", "Usuario");
            }
        }

        [HttpGet]
        public IActionResult MeuSalao()
        {
            var user = _loginUsuario.GetUsuario();
            if (user.IdTipoUsuario == 1)
            {
                Usuario usuario = _loginUsuario.GetUsuario();
                var idempresa = usuario.IdEmpresa;
                var empresa = _empresaRepository.ObterEmpresa(idempresa);

                return View(empresa);
            }
            if (user.IdTipoUsuario > 1)
            {
                return RedirectToAction("AtendimentosUsuario", "Atendimentos");
            }
            else
            {
                return RedirectToAction("Login", "Usuario");
            }
        }
    }
}
