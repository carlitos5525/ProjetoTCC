﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.UI.V3.Pages.Account.Internal;
using Microsoft.AspNetCore.Mvc;
using TCCprojeto.Libs.Login;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Controllers
{
    public class TipoServicoController : Controller
    {
        private ITipoServicoRepository _tipoServicoRepository;

        private LoginUsuario _loginUsuario;

        public TipoServicoController(ITipoServicoRepository tipoServicoRepository, LoginUsuario loginUsuario)
        {
            _tipoServicoRepository = tipoServicoRepository;
            _loginUsuario = loginUsuario;
        }

        public IActionResult Servicos(string searchString, string sortOrder)
        {
            ViewBag.ServicoParam = String.IsNullOrEmpty(sortOrder) ? "Servico" : "";
            Usuario usuario = _loginUsuario.GetUsuario();

            var servicos = _tipoServicoRepository.ListarServicos().Where(a => a.IdEmpresa == usuario.IdEmpresa);

            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }

            if (usuario.IdTipoUsuario < 3)
            {
                if (sortOrder == "Servico")
                {
                    return View(servicos.OrderBy(n => n.NomeServico));
                }

                if (!String.IsNullOrEmpty(searchString))
                {
                    return View(servicos.Where(s => s.NomeServico.ToUpper().Contains(searchString.ToUpper())));
                }
                else
                {
                    return View(servicos);
                }
            }

            else
            {
                return RedirectToAction("AtendimentosUsuario", "Atendimento");
            }

        }

        [HttpGet]
        public IActionResult CreateServico()
        {
            var usuario = _loginUsuario.GetUsuario();
            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }

            if (usuario.IdTipoUsuario < 3)
            {
                return View();
            }

            else
            {
                return RedirectToAction("AtendimentosUsuario", "Atendimento");
            }

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateServico(TipoServico tipoServico)
        {
            Usuario usuario = _loginUsuario.GetUsuario();

            if (ModelState.IsValid)
            {
                tipoServico.IdEmpresa = usuario.IdEmpresa;
                _tipoServicoRepository.CadastrarServico(tipoServico);
                return RedirectToAction(nameof(Servicos));
            }

            return View(tipoServico);
        }

        [HttpGet]
        public IActionResult EditarTipoServico(int? id)
        {
            var usuario = _loginUsuario.GetUsuario();
            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }

            if (usuario.IdTipoUsuario < 3)
            {
                if (id == null)
                {
                    return NotFound();
                }
                var tiposervico = _tipoServicoRepository.ObterServico(id);
                if (tiposervico == null)
                {
                    return NotFound();
                }
                return View(tiposervico);
            }

            else
            {
                return RedirectToAction("AtendimentosUsuario", "Atendimento");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarTipoServico(int? id, [FromForm] TipoServico tipoServico)
        {
            if (id != tipoServico.IdTipoServico)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                var user = _loginUsuario.GetUsuario();
                tipoServico.IdEmpresa = user.IdEmpresa;
                _tipoServicoRepository.AtualizarServico(tipoServico);
            }
            return RedirectToAction(nameof(Servicos));
        }

        [HttpGet]
        public IActionResult DetalhesTipoServico(int? id)
        {
            var usuario = _loginUsuario.GetUsuario();
            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }

            if (usuario.IdTipoUsuario < 3)
            {
                if (id == null)
                {
                    return NotFound();
                }

                var tiposervico = _tipoServicoRepository.ObterServico(id);

                if (tiposervico == null)
                {
                    return NotFound();
                }

                return View(tiposervico);
            }

            else
            {
                return RedirectToAction("AtendimentosUsuario", "Atendimento");
            }
        }

        [HttpGet]
        public IActionResult ExcluirTipoServico(int? id)
        {
            var usuario = _loginUsuario.GetUsuario();
            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }

            if (usuario.IdTipoUsuario < 3)
            {
                if (id == null)
                {
                    return NotFound();
                }
                var tiposervico = _tipoServicoRepository.ObterServico(id);
                if (tiposervico == null)
                {
                    return NotFound();
                }
                return View(tiposervico);
            }

            else
            {
                return RedirectToAction("AtendimentosUsuario", "Atendimento");
            }

        }

        [HttpPost, ActionName("ExcluirTipoServico")]
        [ValidateAntiForgeryToken]
        public IActionResult ExcluirTipoServicoConfirm(int? id)
        {
            _tipoServicoRepository.ExcluirServico(id);
            return RedirectToAction(nameof(Servicos));
        }
    }
}
