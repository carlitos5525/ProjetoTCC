﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TCCprojeto.Migrations
{
    public partial class semRequired : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
