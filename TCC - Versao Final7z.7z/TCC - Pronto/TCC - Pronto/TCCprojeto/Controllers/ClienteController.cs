﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TCCprojeto.Libs.Login;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Controllers
{
    public class ClienteController : Controller
    {
        private readonly IClienteRepository _clienteRepository;

        private LoginUsuario _loginUsuario;

        public ClienteController(IClienteRepository clienteRepository, LoginUsuario loginUsuario)
        {
            _clienteRepository = clienteRepository;
            _loginUsuario = loginUsuario;
        }

        public IActionResult Clientes(string searchString, string sortOrder)
        {
            ViewBag.ClienteParam = String.IsNullOrEmpty(sortOrder) ? "Cliente" : "";
            Usuario usuario = _loginUsuario.GetUsuario();

            var clientes = _clienteRepository.ListarClientes().Where(a => a.IdEmpresa == usuario.IdEmpresa);

            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }
           else
            {
                if (sortOrder == "Cliente")
                {
                    return View(clientes.OrderBy(n => n.Nome));
                }

                if (!String.IsNullOrEmpty(searchString))
                {
                    return View(clientes.Where(c => c.Nome.ToUpper().Contains(searchString.ToUpper())));
                }

                else
                {
                    return View(clientes);
                }
            }
        }

        [HttpGet]
        public IActionResult CadastroCliente()
        {
            var usuario = _loginUsuario.GetUsuario();
            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }

            else
            {
                return View();

            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CadastroCliente(Cliente cliente)
        {
            Usuario usuario = _loginUsuario.GetUsuario();

            if (ModelState.IsValid)
            {
                cliente.IdEmpresa = usuario.IdEmpresa;
                _clienteRepository.CadastrarCliente(cliente);
                return RedirectToAction(nameof(Clientes));
            }

            return View(cliente);
        }

        [HttpGet]
        public IActionResult EditarCliente(int? id)
        {
            var usuario = _loginUsuario.GetUsuario();
            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }

           else
            {
                if (id == null)
                {
                    return NotFound();
                }
                var cliente = _clienteRepository.ObterCliente(id);
                if (cliente == null)
                {
                    return NotFound();
                }
                return View(cliente);
            }

          
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarCliente(int? id, [FromForm] Cliente cliente)
        {
            if (id != cliente.IdCliente)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                var user = _loginUsuario.GetUsuario();
                cliente.IdEmpresa = user.IdEmpresa;
                _clienteRepository.Atualizar(cliente);
            }
            return RedirectToAction(nameof(Clientes));
        }

        [HttpGet]
        public IActionResult VisualizarCliente(int? id)
        {
            var usuario = _loginUsuario.GetUsuario();
            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }

           else
            {
                if (id == null)
                {
                    return NotFound();
                }

                var cliente = _clienteRepository.ObterCliente(id);

                if (cliente == null)
                {
                    return NotFound();
                }

                return View(cliente);
            }

         

        }

        [HttpGet]
        public IActionResult ExcluirCliente(int? id)
        {
            var usuario = _loginUsuario.GetUsuario();
            if (usuario == null)
            {
                return RedirectToAction("Login", "Usuario");
            }

            else
            {
                if (id == null)
                {
                    return NotFound();
                }
                var cliente = _clienteRepository.ObterCliente(id);
                if (cliente == null)
                {
                    return NotFound();
                }
                return View(cliente);
            }

          

        }

        [HttpPost, ActionName("ExcluirCliente")]
        [ValidateAntiForgeryToken]
        public IActionResult ExcluirClienteConfirm(int? id)
        {
            _clienteRepository.Excluir(id);
            return RedirectToAction(nameof(Clientes));
        }
    }
}
