﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.UI.V3.Pages.Account.Internal;
using Microsoft.AspNetCore.Mvc;
using TCCprojeto.Libs.Login;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Controllers
{
    public class TipoServicoController : Controller
    {
        private ITipoServicoRepository _tipoServicoRepository;

        private LoginUsuario _loginUsuario;

        public TipoServicoController(ITipoServicoRepository tipoServicoRepository, LoginUsuario loginUsuario)
        {
            _tipoServicoRepository = tipoServicoRepository;
            _loginUsuario = loginUsuario;
        }

        public IActionResult Servicos(string searchString)
        {
            Usuario usuario = _loginUsuario.GetUsuario();

            var servicos = _tipoServicoRepository.ListarServicos().Where(a => a.IdEmpresa == usuario.IdEmpresa);
            
            if (!String.IsNullOrEmpty(searchString))
            {
                return View(servicos.Where(s => s.NomeServico.ToUpper().Contains(searchString.ToUpper())));
            }
            else
            {
                return View(servicos);
            }

        }

        [HttpGet]
        public IActionResult CreateServico()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateServico(TipoServico tipoServico)
        {
            Usuario usuario = _loginUsuario.GetUsuario();

            if (ModelState.IsValid)
            {
                tipoServico.IdEmpresa = usuario.IdEmpresa;
                _tipoServicoRepository.CadastrarServico(tipoServico);
                return RedirectToAction(nameof(Servicos));
            }

            return View(tipoServico);
        }

        [HttpGet]
        public IActionResult EditarTipoServico(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var tiposervico = _tipoServicoRepository.ObterServico(id);
            if (tiposervico == null)
            {
                return NotFound();
            }
            return View(tiposervico);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarTipoServico(int? id, [FromForm] TipoServico tipoServico)
        {
            if (id != tipoServico.IdTipoServico)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                var user = _loginUsuario.GetUsuario();
                tipoServico.IdEmpresa = user.IdEmpresa;
                _tipoServicoRepository.AtualizarServico(tipoServico);
            }
            return RedirectToAction(nameof(Servicos));
        }

        [HttpGet]
        public IActionResult DetalhesTipoServico(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tiposervico = _tipoServicoRepository.ObterServico(id);

            if (tiposervico == null)
            {
                return NotFound();
            }

            return View(tiposervico);
        }

        [HttpGet]
        public IActionResult ExcluirTipoServico(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var tiposervico = _tipoServicoRepository.ObterServico(id);
            if (tiposervico == null)
            {
                return NotFound();
            }
            return View(tiposervico);
        }

        [HttpPost, ActionName("ExcluirTipoServico")]
        [ValidateAntiForgeryToken]
        public IActionResult ExcluirTipoServicoConfirm(int? id)
        {
            _tipoServicoRepository.ExcluirServico(id);
            return RedirectToAction(nameof(Servicos));
        }
    }
}
