﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TCCprojeto.Models
{
    public class TipoServico
    {
        [Key]
        public int? IdTipoServico { get; set; }
        [Display(Name = "Nome do serviço")]
        public string NomeServico { get; set; }
        [Display(Name = "Preço")]
        public decimal? Preco { get; set; }
        [Display(Name = "Descrição do Serviço")]
        public string descricao { get; set; }

        public virtual ICollection<Atendimento> Atendimentos { get; set; }

        [Display(Name = "Código da Empresa")]
        public int? IdEmpresa { get; set; }//chave estrangeira
        public virtual Empresa Empresa { get; set; }
    }
}
