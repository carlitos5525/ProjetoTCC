﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Models
{
    public class Usuario
    {
        [Key]
        public int? IdUsuario { get; set; }
        [Display(Name ="Nome do Funcionário")]
        public string NomeUsuario { get; set; }
        [Display(Name ="E-mail")]
        public string Email { get; set; }
        public string Senha { get; set; }

        public virtual ICollection<Atendimento> Atendimentos { get; set; }
    }
}
