﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Models
{
    public class TipoServico
    {
        [Key]
        public int? IdTipoServico { get; set; }
        [Display(Name = "Nome do serviço")]
        public string NomeServico { get; set; }
        [Display(Name = "Preço")]
        public int Preco { get; set; }
    }
}
