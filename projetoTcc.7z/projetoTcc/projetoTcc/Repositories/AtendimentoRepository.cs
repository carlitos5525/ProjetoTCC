﻿using Microsoft.EntityFrameworkCore;
using projetoTcc.Data;
using projetoTcc.Models;
using projetoTcc.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Repositories
{
    public class AtendimentoRepository : IAtendimentoRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public AtendimentoRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        
        public void AtualizarAtendimento(Atendimento atendimento)
        {
            _dbContext.Update(atendimento);
            _dbContext.SaveChanges();
        }

        public void CriarAtendimento(Atendimento atendimento)
        {
            _dbContext.Add(atendimento);
            _dbContext.SaveChanges();
        }

        public void ExcluirAtendimento(int? id)
        {
            Atendimento atendimento = ObterAtendimento(id);
            _dbContext.Remove(atendimento);
            _dbContext.SaveChanges();
        }

        public List<Atendimento> ListarAtendimentos()
        {
            var atendimentos = _dbContext.Atendimentos.Include(a => a.TipoServico).Include(a => a.Cliente).Include(a => a.Usuario);
            return(atendimentos.ToList());
        }

        public Atendimento ObterAtendimento(int? id)
        {
            return (_dbContext.Atendimentos.Find(id));
        }

        public Atendimento ObterComDetalhes(int? id)
        {
            Atendimento atendimento = _dbContext.Atendimentos.Include(a => a.Cliente).Include(a => a.TipoServico)
                .Include(a => a.Usuario).FirstOrDefault(a => a.IdAtendimento == id);
            return (atendimento);
        }

        public List<Atendimento> ListarPorNome(string searchString)
        {
            var atendimentos = ListarAtendimentos().Where(a => a.Cliente.nome.ToUpper().Contains(searchString.ToUpper())
            || a.Usuario.NomeUsuario.ToUpper().Contains(searchString.ToUpper()));
            return (atendimentos.ToList());

        }
    }
}
