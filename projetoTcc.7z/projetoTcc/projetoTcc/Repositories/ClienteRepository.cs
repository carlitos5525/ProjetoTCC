﻿using projetoTcc.Data;
using projetoTcc.Models;
using projetoTcc.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Repositories
{
    public class ClienteRepository : IClienteRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public ClienteRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        
        public void Atualizar(Cliente cliente)
        {
            _dbContext.Update(cliente);
            _dbContext.SaveChanges();
        }

        public void CadastrarCliente(Cliente cliente)
        {
            _dbContext.Add(cliente);
            _dbContext.SaveChanges();
        }

        public void Excluir(int? id)
        {
            Cliente cliente = ObterCliente(id);
            _dbContext.Remove(cliente);
            _dbContext.SaveChanges();
        }

        public List<Cliente> ListarClientes()
        {
            return (_dbContext.Clientes.ToList());
        }

        public Cliente ObterCliente(int? id)
        {
            return (_dbContext.Clientes.Find(id));
        }

        public List<Cliente> ListarPorNome(string searchString)
        {
            var clientes = ListarClientes().Where(c => c.nome.ToUpper().Contains(searchString.ToUpper())
                || c.email.Contains(searchString));
            return (clientes.ToList());

        }
    }
}
