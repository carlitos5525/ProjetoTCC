﻿using projetoTcc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Repositories.Interfaces
{
    public interface ITipoServicoRepository
    {
        TipoServico ObterServico(int? id);
        List<TipoServico> ListarServicos();
        void CadastrarServico(TipoServico tipoServico);
        void AtualizarServico(TipoServico tipoServico);
        void ExcluirServico(int? id);
        List<TipoServico> ListarPorNome(string searchString);
    }
}
