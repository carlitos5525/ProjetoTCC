﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using projetoTcc.Models;

namespace projetoTcc.Repositories.Interfaces
{
    public interface IClienteRepository
    {
        Cliente ObterCliente(int? id);
        List<Cliente> ListarClientes();
        void CadastrarCliente(Cliente cliente);
        void Atualizar(Cliente cliente);
        void Excluir(int? id);
        List<Cliente> ListarPorNome(string searchString);
    }
}
