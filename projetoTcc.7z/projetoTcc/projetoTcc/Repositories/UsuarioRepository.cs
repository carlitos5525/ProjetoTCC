﻿using projetoTcc.Data;
using projetoTcc.Models;
using projetoTcc.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Repositories
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public UsuarioRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AtualizarUsuario(Usuario usuario)
        {
            _dbContext.Update(usuario);
            _dbContext.SaveChanges();
        }

        public void CadastrarUsuario(Usuario usuario)
        {
            _dbContext.Add(usuario);
            _dbContext.SaveChanges();
        }

        public void ExcluirUsuario(int? id)
        {
            var usuario = ObterUsuario(id);
            _dbContext.Remove(usuario);
            _dbContext.SaveChanges();
        }

        public List<Usuario> ListarPorNome(string searchString)
        {
            var usuarios = _dbContext.Usuarios.Where(s => s.NomeUsuario.ToUpper().Contains(searchString.ToUpper()));
            return (usuarios.ToList());
        }

        public List<Usuario> ListarUsuarios()
        {
            return (_dbContext.Usuarios.ToList());
        }

        public Usuario ObterUsuario(int? id)
        {
            return (_dbContext.Usuarios.Find(id));
        }
    }
}
