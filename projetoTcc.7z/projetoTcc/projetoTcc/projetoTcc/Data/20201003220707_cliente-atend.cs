﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace projetoTcc.data
{
    public partial class clienteatend : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "IdCliente",
                table: "Atendimentos",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Atendimentos_IdCliente",
                table: "Atendimentos",
                column: "IdCliente");

            migrationBuilder.AddForeignKey(
                name: "FK_Atendimentos_Clientes_IdCliente",
                table: "Atendimentos",
                column: "IdCliente",
                principalTable: "Clientes",
                principalColumn: "idCliente",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Atendimentos_Clientes_IdCliente",
                table: "Atendimentos");

            migrationBuilder.DropIndex(
                name: "IX_Atendimentos_IdCliente",
                table: "Atendimentos");

            migrationBuilder.DropColumn(
                name: "IdCliente",
                table: "Atendimentos");
        }
    }
}
