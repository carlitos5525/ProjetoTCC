﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using projetoTcc.Data;
using projetoTcc.Models;

namespace projetoTcc.Controllers
{
    public class AtendimentoController : Controller
    {
        private readonly ApplicationDbContext _dbcontext;

        public AtendimentoController(ApplicationDbContext Dbcontext)
        {
            _dbcontext = Dbcontext;
        }

       public IActionResult Atendimentos()
        {
            var atendimentos = _dbcontext.Atendimentos.Include(a => a.TipoServico).Include(a => a.Cliente).Include(a => a.Usuario);
            return View(atendimentos.ToList());
        }
        
        
        [HttpGet]
        public IActionResult CriarAtendimento()
        {
            // Para preencher a dropdownList
            // Utiliza-se o ViewData para passar os nomes dos fabricntes para a view de Cadastro de Carros
            ViewData["IdUsuario"] = new SelectList(_dbcontext.Usuarios, "IdUsuario", "IdUsuario");
            ViewData["idCliente"] = new SelectList(_dbcontext.Clientes, "idCliente", "nome");
            ViewData["IdTipoServico"] = new SelectList(_dbcontext.TipoServicos, "IdTipoServico", "NomeServico");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CriarAtendimento(Atendimento atendimento)
        {
            if (ModelState.IsValid)
            {
                _dbcontext.Add(atendimento);
                await _dbcontext.SaveChangesAsync();
                return RedirectToAction(nameof(Atendimentos));
            }
            return View(atendimento);
        }

        [HttpGet]
        public async Task<IActionResult> EditarAtendimento(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var atendimento = await _dbcontext.Atendimentos.FindAsync(id);
            if (atendimento == null)
            {
                return NotFound();
            }
            // Para preencher a dropdownList
            // Utiliza-se o ViewData para passar os nomes dos fabricntes para a view de Edição de Atendimentos
            ViewData["IdTipoServico"] = new SelectList(_dbcontext.TipoServicos, "IdTipoServico", "NomeServico");
            ViewData["idCliente"] = new SelectList(_dbcontext.Clientes, "idCliente", "nome");
            ViewData["IdUsuario"] = new SelectList(_dbcontext.Usuarios, "IdUsuario", "NomeUsuario");

            return View(atendimento);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarAtendimento(int? id, [FromForm] Atendimento atendimento)
        {
            if (id != atendimento.IdAtendimento)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _dbcontext.Update(atendimento);
                await _dbcontext.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Atendimentos));
        }

        public async Task<IActionResult> DetalhesAtendimento(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var atendimento = await _dbcontext.Atendimentos.Include(a => a.Cliente).Include(b => b.TipoServico).FirstOrDefaultAsync(a => a.IdAtendimento == id);

            if (atendimento == null)
            {
                return NotFound();
            }

            return View(atendimento);
        }

        [HttpGet]
        public async Task<ActionResult> DeletarAtendimento(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var atendimento = await _dbcontext.Atendimentos.Include(a => a.TipoServico).Include(a => a.Cliente).Include(a => a.Usuario)
                .FirstOrDefaultAsync(f => f.IdAtendimento == id);
            if (atendimento == null)
            {
                return NotFound();
            }
            return View(atendimento);
        }

        [HttpPost, ActionName("DeletarAtendimento")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeletarAtendimentoConfir(int? id)
        {
            var atendimento = await _dbcontext.Atendimentos.FindAsync(id);
            _dbcontext.Atendimentos.Remove(atendimento);
            await _dbcontext.SaveChangesAsync();
            return RedirectToAction(nameof(Atendimentos));
        }
    }
}
