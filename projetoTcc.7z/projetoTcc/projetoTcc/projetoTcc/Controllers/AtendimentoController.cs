﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using projetoTcc.Data;
using projetoTcc.Models;

namespace projetoTcc.Controllers
{
    public class AtendimentoController : Controller
    {
        private readonly ApplicationDbContext _dbcontext;

        public AtendimentoController(ApplicationDbContext Dbcontext)
        {
            _dbcontext = Dbcontext;
        }

       public IActionResult Atendimentos()
        {
            var atendimentos = _dbcontext.Atendimentos.Include(a => a.TipoServico);
            return View(atendimentos.ToList());
        }
        
        
        [HttpGet]
        public IActionResult CriarAtendimento()
        {
            // Para preencher a dropdownList
            // Utiliza-se o ViewData para passar os nomes dos fabricntes para a view de Cadastro de Carros
            ViewData["IdTipoServico"] = new SelectList(_dbcontext.TipoServicos, "IdTipoServico", "NomeServico");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CriarAtendimento(Atendimento atendimento)
        {
            if (ModelState.IsValid)
            {
                _dbcontext.Add(atendimento);
                await _dbcontext.SaveChangesAsync();
                return RedirectToAction(nameof(Atendimentos));
            }
            return View(atendimento);
        }



        public IActionResult Index()
        {
            return View();
        }
    }
}
