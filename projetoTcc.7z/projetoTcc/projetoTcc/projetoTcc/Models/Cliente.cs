﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Models
{
    public class Cliente
    {
        [Key]
        public int? idCliente { get; set; }
        [Display(Name = "Nome do Cliente")]
        public string nome { get; set; }
        [Display(Name ="E-mail")]
        public string email { get; set; }
        [Display(Name ="Número de telefone")]
        public string telefone { get; set; }

        public virtual ICollection<Atendimento> Atendimentos { get; set; }

    }
}
