﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Models
{
    public class Atendimento
    {
       [Key]
        public int? IdAtendimento { get; set; }
        [Display(Name ="Data de Início")]
        public DateTime DataInicio { get; set; }
        public string Observacoes { get; set; }


        [Display(Name = "Código Fabricante")]
        public int IdTipoServico { get; set; } // Chave estrangeira
        public virtual TipoServico TipoServico { get; set; }
    }
}
