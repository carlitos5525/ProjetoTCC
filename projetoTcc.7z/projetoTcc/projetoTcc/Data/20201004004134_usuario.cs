﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace projetoTcc.data
{
    public partial class usuario : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
