﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace projetoTcc.data
{
    public partial class addcliente : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "Preco",
                table: "TipoServicos",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "Preco",
                table: "TipoServicos",
                nullable: true,
                oldClrType: typeof(int));
        }
    }
}
