﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace projetoTcc.data
{
    public partial class cc : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Atendimento_TipoServicos_IdTipoServico",
                table: "Atendimento");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Atendimento",
                table: "Atendimento");

            migrationBuilder.RenameTable(
                name: "Atendimento",
                newName: "Atendimentos");

            migrationBuilder.RenameIndex(
                name: "IX_Atendimento_IdTipoServico",
                table: "Atendimentos",
                newName: "IX_Atendimentos_IdTipoServico");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Atendimentos",
                table: "Atendimentos",
                column: "IdAtendimento");

            migrationBuilder.AddForeignKey(
                name: "FK_Atendimentos_TipoServicos_IdTipoServico",
                table: "Atendimentos",
                column: "IdTipoServico",
                principalTable: "TipoServicos",
                principalColumn: "IdTipoServico",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Atendimentos_TipoServicos_IdTipoServico",
                table: "Atendimentos");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Atendimentos",
                table: "Atendimentos");

            migrationBuilder.RenameTable(
                name: "Atendimentos",
                newName: "Atendimento");

            migrationBuilder.RenameIndex(
                name: "IX_Atendimentos_IdTipoServico",
                table: "Atendimento",
                newName: "IX_Atendimento_IdTipoServico");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Atendimento",
                table: "Atendimento",
                column: "IdAtendimento");

            migrationBuilder.AddForeignKey(
                name: "FK_Atendimento_TipoServicos_IdTipoServico",
                table: "Atendimento",
                column: "IdTipoServico",
                principalTable: "TipoServicos",
                principalColumn: "IdTipoServico",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
