﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace projetoTcc.data
{
    public partial class novousuario : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Atendimentos_Usuarios_UsuarioIdUsuario",
                table: "Atendimentos");

            migrationBuilder.DropColumn(
                name: "PkUsuario",
                table: "Atendimentos");

            migrationBuilder.RenameColumn(
                name: "UsuarioIdUsuario",
                table: "Atendimentos",
                newName: "IdUsuario");

            migrationBuilder.RenameIndex(
                name: "IX_Atendimentos_UsuarioIdUsuario",
                table: "Atendimentos",
                newName: "IX_Atendimentos_IdUsuario");

            migrationBuilder.AddForeignKey(
                name: "FK_Atendimentos_Usuarios_IdUsuario",
                table: "Atendimentos",
                column: "IdUsuario",
                principalTable: "Usuarios",
                principalColumn: "IdUsuario",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Atendimentos_Usuarios_IdUsuario",
                table: "Atendimentos");

            migrationBuilder.RenameColumn(
                name: "IdUsuario",
                table: "Atendimentos",
                newName: "UsuarioIdUsuario");

            migrationBuilder.RenameIndex(
                name: "IX_Atendimentos_IdUsuario",
                table: "Atendimentos",
                newName: "IX_Atendimentos_UsuarioIdUsuario");

            migrationBuilder.AddColumn<int>(
                name: "PkUsuario",
                table: "Atendimentos",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_Atendimentos_Usuarios_UsuarioIdUsuario",
                table: "Atendimentos",
                column: "UsuarioIdUsuario",
                principalTable: "Usuarios",
                principalColumn: "IdUsuario",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
