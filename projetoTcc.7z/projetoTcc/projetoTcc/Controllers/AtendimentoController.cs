﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using projetoTcc.Data;
using projetoTcc.Models;
using projetoTcc.Repositories.Interfaces;

namespace projetoTcc.Controllers
{
    public class AtendimentoController : Controller
    {
        private readonly IAtendimentoRepository _atendimentoRepository;

        private readonly ApplicationDbContext _dbcontext;

        public AtendimentoController(IAtendimentoRepository atendimentoRepository, ApplicationDbContext applicationDbContext)
        {
            _atendimentoRepository = atendimentoRepository;
            _dbcontext = applicationDbContext;
        }

       public IActionResult Atendimentos(string searchString)
        { 
            if (!String.IsNullOrEmpty(searchString))
            { 
                return View(_atendimentoRepository.ListarPorNome(searchString));
            }

            else
            {
                return View(_atendimentoRepository.ListarAtendimentos());
            }
        }
        
        
        [HttpGet]
        public IActionResult CriarAtendimento()
        {
            // Para preencher a dropdownList
            // Utiliza-se o ViewData para passar os nomes dos fabricntes para a view de Cadastro de Carros
            ViewData["IdUsuario"] = new SelectList(_dbcontext.Usuarios, "IdUsuario", "NomeUsuario");
            ViewData["idCliente"] = new SelectList(_dbcontext.Clientes, "idCliente", "nome");
            ViewData["IdTipoServico"] = new SelectList(_dbcontext.TipoServicos, "IdTipoServico", "NomeServico");
            return View();
        }

        [HttpPost]
        public IActionResult CriarAtendimento(Atendimento atendimento)
        {
            if (ModelState.IsValid)
            {
                _atendimentoRepository.CriarAtendimento(atendimento);
                return RedirectToAction(nameof(Atendimentos));
            }
            return View(atendimento);
        }

        [HttpGet]
        public IActionResult EditarAtendimento(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var atendimento = _atendimentoRepository.ObterAtendimento(id);
            if (atendimento == null)
            {
                return NotFound();
            }
            // Para preencher a dropdownList
            // Utiliza-se o ViewData para passar os nomes dos fabricntes para a view de Edição de Atendimentos
            ViewData["IdTipoServico"] = new SelectList(_dbcontext.TipoServicos, "IdTipoServico", "NomeServico");
            ViewData["idCliente"] = new SelectList(_dbcontext.Clientes, "idCliente", "nome");
            ViewData["IdUsuario"] = new SelectList(_dbcontext.Usuarios, "IdUsuario", "NomeUsuario");

            return View(atendimento);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarAtendimento(int? id, [FromForm] Atendimento atendimento)
        {
            if (id != atendimento.IdAtendimento)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _atendimentoRepository.AtualizarAtendimento(atendimento);
            }
            return RedirectToAction(nameof(Atendimentos));
        }

        public IActionResult DetalhesAtendimento(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var atendimento = _atendimentoRepository.ObterComDetalhes(id);

            if (atendimento == null)
            {
                return NotFound();
            }

            return View(atendimento);
        }

        [HttpGet]
        public ActionResult DeletarAtendimento(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var atendimento = _atendimentoRepository.ObterComDetalhes(id);
            if (atendimento == null)
            {
                return NotFound();
            }
            return View(atendimento);
        }

        [HttpPost, ActionName("DeletarAtendimento")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletarAtendimentoConfir(int? id)
        {
            _atendimentoRepository.ExcluirAtendimento(id);
            return RedirectToAction(nameof(Atendimentos));
        }
    }
}
