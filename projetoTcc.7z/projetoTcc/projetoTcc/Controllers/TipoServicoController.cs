﻿using Microsoft.AspNetCore.Mvc;
using projetoTcc.Data;
using projetoTcc.Models;
using projetoTcc.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Controllers
{
    public class TipoServicoController : Controller
    {
        private ITipoServicoRepository _tipoServicoRepository;

        public TipoServicoController(ITipoServicoRepository tipoServicoRepository)
        {
            _tipoServicoRepository = tipoServicoRepository;
        }

        public IActionResult Servicos(string searchString)
        {
            if(!String.IsNullOrEmpty(searchString))
            {
                return View(_tipoServicoRepository.ListarPorNome(searchString));
            }
            else
            {
                return View(_tipoServicoRepository.ListarServicos());
            }
            
        }

        [HttpGet]
        public IActionResult CreateServico()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateServico(TipoServico tipoServico)
        {
            if (ModelState.IsValid)
            {
                _tipoServicoRepository.CadastrarServico(tipoServico);
                return RedirectToAction(nameof(Servicos));
            }

            return View(tipoServico);
        }

        [HttpGet]
        public IActionResult EditarTipoServico(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var tiposervico = _tipoServicoRepository.ObterServico(id);
            if (tiposervico == null)
            {
                return NotFound();
            }
            return View(tiposervico);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarTipoServico(int? id, [FromForm] TipoServico tipoServico)
        {
            if (id != tipoServico.IdTipoServico)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _tipoServicoRepository.AtualizarServico(tipoServico);
            }
            return RedirectToAction(nameof(Servicos));
        }

        [HttpGet]
        public IActionResult DetalhesTipoServico(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tiposervico = _tipoServicoRepository.ObterServico(id);

            if (tiposervico == null)
            {
                return NotFound();
            }

            return View(tiposervico);
        }

        [HttpGet]
        public IActionResult ExcluirTipoServico(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var tiposervico = _tipoServicoRepository.ObterServico(id);
            if (tiposervico == null)
            {
                return NotFound();
            }
            return View(tiposervico);
        }

        [HttpPost, ActionName("ExcluirTipoServico")]
        [ValidateAntiForgeryToken]
        public IActionResult ExcluirTipoServicoConfirm(int? id)
        {
            _tipoServicoRepository.ExcluirServico(id);
            return RedirectToAction(nameof(Servicos));
        }

    }
}
