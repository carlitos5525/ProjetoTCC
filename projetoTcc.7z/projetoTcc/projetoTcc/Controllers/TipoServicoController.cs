﻿using Microsoft.AspNetCore.Mvc;
using projetoTcc.Data;
using projetoTcc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Controllers
{
    public class TipoServicoController : Controller
    {
        private readonly ApplicationDbContext _dbcontext;

        public TipoServicoController(ApplicationDbContext Dbcontext)
        {
            _dbcontext = Dbcontext;
        }

        public IActionResult Servicos()
        {
            IList<TipoServico> tipoServicos = _dbcontext.TipoServicos.ToList();
            return View(tipoServicos);
        }

        [HttpGet]
        public IActionResult CreateServico()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateServico(TipoServico tipoServico)
        {
            if (ModelState.IsValid)
            {
                _dbcontext.Add(tipoServico);
                await _dbcontext.SaveChangesAsync();
                return RedirectToAction(nameof(Servicos));
            }

            return View(tipoServico);
        }

        [HttpGet]
        public async Task<IActionResult> EditarTipoServico(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var tiposervico = await _dbcontext.TipoServicos.FindAsync(id);
            if (tiposervico == null)
            {
                return NotFound();
            }
            return View(tiposervico);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarTipoServico(int? id, [FromForm] TipoServico tipoServico)
        {
            if (id != tipoServico.IdTipoServico)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _dbcontext.Update(tipoServico);
                await _dbcontext.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Servicos));
        }

        [HttpGet]
        public async Task<IActionResult> DetalhesTipoServico(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tiposervico = await _dbcontext.TipoServicos.FindAsync(id);

            if (tiposervico == null)
            {
                return NotFound();
            }

            return View(tiposervico);
        }

        [HttpGet]
        public async Task<IActionResult> ExcluirTipoServico(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var tiposervico = await _dbcontext.TipoServicos.FindAsync(id);
            if (tiposervico == null)
            {
                return NotFound();
            }
            return View(tiposervico);
        }

        [HttpPost, ActionName("ExcluirTipoServico")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ExcluirTipoServicoConfirm(int? id)
        {
            var tiposervico = await _dbcontext.TipoServicos.FindAsync(id);
            _dbcontext.Remove(tiposervico);
            await _dbcontext.SaveChangesAsync();
            return RedirectToAction(nameof(Servicos));
        }

    }
}
