﻿using Microsoft.AspNetCore.Mvc;
using projetoTcc.Data;
using projetoTcc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace projetoTcc.Controllers
{
    public class TipoServicoController : Controller
    {
        private readonly ApplicationDbContext _dbcontext;

        public TipoServicoController(ApplicationDbContext Dbcontext)
        {
            _dbcontext = Dbcontext;
        }

        public IActionResult Servicos()
        {
            IList<TipoServico> tipoServicos = _dbcontext.TipoServicos.ToList();
            return View(tipoServicos);
        }

        [HttpGet]
        public IActionResult CreateServico()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateServico(TipoServico tipoServico)
        {
           // if(ModelState.IsValid)
            
                _dbcontext.Add(tipoServico);
                await _dbcontext.SaveChangesAsync();
                return RedirectToAction(nameof(Servicos));
            

            //return View(tipoServico);
        }

        public IActionResult Index()
        {
            return View();
        }

    }
}
