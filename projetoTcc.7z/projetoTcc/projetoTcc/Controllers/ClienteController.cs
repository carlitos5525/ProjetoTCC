﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using projetoTcc.Data;
using projetoTcc.Models;

namespace projetoTcc.Controllers
{
    public class ClienteController : Controller
    {
       private readonly ApplicationDbContext _dbcontext;

        public ClienteController(ApplicationDbContext Dbcontext)
        {
          _dbcontext = Dbcontext;
        }

        public IActionResult Clientes()
        {
           IList<Cliente> clientes = _dbcontext.Clientes.ToList();
           return View(clientes);
        }

        [HttpGet]
        public IActionResult CadastroCliente()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CadastroCliente(Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                _dbcontext.Add(cliente);
                await _dbcontext.SaveChangesAsync();
                return RedirectToAction(nameof(Clientes));
            }

            return View(cliente);
        }

        [HttpGet]
        public async Task<IActionResult> EditarCliente(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var cliente = await _dbcontext.Clientes.FindAsync(id);
            if (cliente == null)
            {
                return NotFound();
            }
            return View(cliente);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarCliente(int? id, [FromForm] Cliente cliente)
        {
            if (id != cliente.idCliente)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _dbcontext.Update(cliente);
                await _dbcontext.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Clientes));
        }

        [HttpGet]
        public async Task<IActionResult> VisualizarCliente(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cliente = await _dbcontext.Clientes.FindAsync(id);

            if (cliente == null)
            {
                return NotFound();
            }

            return View(cliente);
        }
        
        [HttpGet]
        public async Task<IActionResult> ExcluirCliente(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var cliente = await _dbcontext.Clientes.FindAsync(id);
            if( cliente == null)
            {
                return NotFound();
            }
            return View(cliente);
        }

        [HttpPost, ActionName("ExcluirCliente")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ExcluirClienteConfirm(int? id)
        {
            var cliente = await _dbcontext.Clientes.FindAsync(id);
            _dbcontext.Remove(cliente);
            await _dbcontext.SaveChangesAsync();
            return RedirectToAction(nameof(Clientes));
        }





    }
}
