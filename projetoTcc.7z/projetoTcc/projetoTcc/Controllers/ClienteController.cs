﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using projetoTcc.Data;
using projetoTcc.Models;
using projetoTcc.Repositories.Interfaces;

namespace projetoTcc.Controllers
{
    public class ClienteController : Controller
    {
        private readonly IClienteRepository _clienteRepositoy;

        public ClienteController(IClienteRepository clienteRepository)
        {
            _clienteRepositoy = clienteRepository;
        }

        public IActionResult Clientes(string searchString)
        {
            if (!String.IsNullOrEmpty(searchString))
            {
                return View(_clienteRepositoy.ListarPorNome(searchString));
            }

            else
            {
                return View(_clienteRepositoy.ListarClientes());
            }
        }

        [HttpGet]
        public IActionResult CadastroCliente()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CadastroCliente(Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                _clienteRepositoy.CadastrarCliente(cliente);
                return RedirectToAction(nameof(Clientes));
            }

            return View(cliente);
        }

        [HttpGet]
        public IActionResult EditarCliente(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var cliente =_clienteRepositoy.ObterCliente(id);
            if (cliente == null)
            {
                return NotFound();
            }
            return View(cliente);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarCliente(int? id, [FromForm] Cliente cliente)
        {
            if (id != cliente.idCliente)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _clienteRepositoy.Atualizar(cliente);
            }
            return RedirectToAction(nameof(Clientes));
        }

        [HttpGet]
        public IActionResult VisualizarCliente(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cliente = _clienteRepositoy.ObterCliente(id);

            if (cliente == null)
            {
                return NotFound();
            }

            return View(cliente);
        }
        
        [HttpGet]
        public IActionResult ExcluirCliente(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var cliente = _clienteRepositoy.ObterCliente(id);
            if( cliente == null)
            {
                return NotFound();
            }
            return View(cliente);
        }

        [HttpPost, ActionName("ExcluirCliente")]
        [ValidateAntiForgeryToken]
        public IActionResult ExcluirClienteConfirm(int? id)
        {
            _clienteRepositoy.Excluir(id);
            return RedirectToAction(nameof(Clientes));
        }





    }
}
