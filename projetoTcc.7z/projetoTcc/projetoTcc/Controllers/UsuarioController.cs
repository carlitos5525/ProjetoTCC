﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using projetoTcc.Data;
using projetoTcc.Models;
using projetoTcc.Repositories.Interfaces;

namespace projetoTcc.Controllers
{
    public class UsuarioController : Controller
    {
        private IUsuarioRepository _usuarioRepository;

        public UsuarioController(IUsuarioRepository usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;
        }

        public IActionResult Usuarios(string searchString)
        {

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(_usuarioRepository.ListarPorNome(searchString));

            }
            else
            {
                return View(_usuarioRepository.ListarUsuarios());
            }
            
        }

        [HttpGet]
        public IActionResult CadastroUsuario()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CadastroUsuario(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                _usuarioRepository.CadastrarUsuario(usuario);
                return RedirectToAction(nameof(Usuarios));
            }

            return View(usuario);
        }

        [HttpGet]
        public IActionResult EditarUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var usuario = _usuarioRepository.ObterUsuario(id);
            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarUsuario(int? id, [FromForm] Usuario usuario)
        {
            if (id != usuario.IdUsuario)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _usuarioRepository.AtualizarUsuario(usuario);
            }
            return RedirectToAction(nameof(Usuarios));
        }

        [HttpGet]
        public IActionResult DetalhesUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = _usuarioRepository.ObterUsuario(id);

            if (usuario == null)
            {
                return NotFound();
            }

            return View(usuario);
        }

        [HttpGet]
        public IActionResult ExcluirUsuario(int? id)
        {
            if(id == null)
            {
                return (NotFound());
            }
            var usuario = _usuarioRepository.ObterUsuario(id);
            if(usuario == null)
            {
                return (NotFound());
            }

            return View(usuario);
        }

        [HttpPost, ActionName("ExcluirUsuario")]
        [ValidateAntiForgeryToken]
        public IActionResult ExcluirUsuarioConfirm(int? id)
        {
            _usuarioRepository.ExcluirUsuario(id);
            return RedirectToAction(nameof(Usuarios));
        }

    }
}
