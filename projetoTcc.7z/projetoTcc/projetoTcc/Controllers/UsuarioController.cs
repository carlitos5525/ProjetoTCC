﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using projetoTcc.Data;
using projetoTcc.Models;

namespace projetoTcc.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly ApplicationDbContext _dbcontext;

        public UsuarioController(ApplicationDbContext Dbcontext)
        {
            _dbcontext = Dbcontext;
        }

        public IActionResult Usuarios(string searchString)
        {
            var usuarios = _dbcontext.Usuarios;

            if (!String.IsNullOrEmpty(searchString))
            {
                var usuarios_nome = usuarios.Where(u => u.NomeUsuario.ToUpper().Contains(searchString.ToUpper()));
                return View(usuarios_nome);

            }

            return View(usuarios.ToList());
        }

        [HttpGet]
        public IActionResult CadastroUsuario()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CadastroUsuario(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                _dbcontext.Add(usuario);
                await _dbcontext.SaveChangesAsync();
                return RedirectToAction(nameof(Usuarios));
            }

            return View(usuario);
        }

        [HttpGet]
        public async Task<IActionResult> EditarUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var usuario = await _dbcontext.Usuarios.FindAsync(id);
            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarUsuario(int? id, [FromForm] Usuario usuario)
        {
            if (id != usuario.IdUsuario)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _dbcontext.Update(usuario);
                await _dbcontext.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Usuarios));
        }

        [HttpGet]
        public async Task<IActionResult> DetalhesUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = await _dbcontext.Usuarios.FindAsync(id);

            if (usuario == null)
            {
                return NotFound();
            }

            return View(usuario);
        }

    }
}
