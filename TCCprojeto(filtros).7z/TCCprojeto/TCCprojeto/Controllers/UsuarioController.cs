﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TCCprojeto.Data;
using TCCprojeto.Libs.Login;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Controllers
{
    public class UsuarioController : Controller
    {
        private IUsuarioRepository _usuarioRepository;

        private LoginUsuario _loginUsuario;

        private readonly ApplicationDbContext _dbcontext;

        public UsuarioController(IUsuarioRepository usuarioRepository, LoginUsuario loginUsuario, ApplicationDbContext dbContext)
        {
            _usuarioRepository = usuarioRepository;
            _loginUsuario = loginUsuario;
            _dbcontext = dbContext;
        }

        public IActionResult Usuarios(string searchString)
        {
            Usuario user = _loginUsuario.GetUsuario();

            var usuarios = _usuarioRepository.ListarUsuarios().Where(u => u.IdEmpresa == user.IdEmpresa);
            
            if (!String.IsNullOrEmpty(searchString))
            {
                return View(usuarios.Where(s => s.NomeUsuario.ToUpper().Contains(searchString.ToUpper())));
            }
            else
            {
                return View(usuarios);
            }

        }

        [HttpGet]
        public IActionResult CadastroPrimeiroUsuario()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CadastroPrimeiroUsuario(Usuario usuario, Empresa empresa) //esse é o método para o primeiro cadastro no sistema
        {
            if (ModelState.IsValid)
            {
                usuario.IdEmpresa = empresa.IdEmpresa;
                usuario.IdTipoUsuario = 1;
                _usuarioRepository.CadastrarUsuario(usuario);
                return RedirectToAction(nameof(ConfirmPrimeiroUsuario));
            }

            return View(usuario);
        }

        [HttpGet]
        public IActionResult CreateUsuario()
        {
            ViewData["IdTipoUsuario"] = new SelectList(_dbcontext.TipoUsuarios, "IdTipoUsuario", "NomeTipoUsuario");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateUsuario(Usuario usuario) 
        {
            Usuario user = _loginUsuario.GetUsuario();
            if (ModelState.IsValid)
            {
                usuario.IdEmpresa = user.IdEmpresa;
                _usuarioRepository.CadastrarUsuario(usuario);
                return RedirectToAction(nameof(Usuarios));
            }

            return View(usuario);
        }

        [HttpGet]
        public IActionResult EditarUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var usuario = _usuarioRepository.ObterUsuario(id);
            if (usuario == null)
            {
                return NotFound();
            }
            ViewData["IdTipoUsuario"] = new SelectList(_dbcontext.TipoUsuarios, "IdTipoUsuario", "NomeTipoUsuario");
            return View(usuario);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarUsuario(int? id, [FromForm] Usuario usuario)
        {
            if (id != usuario.IdUsuario)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                var user = _loginUsuario.GetUsuario();
                usuario.IdEmpresa = user.IdEmpresa;
                _usuarioRepository.AtualizarUsuario(usuario);
            }
            return RedirectToAction(nameof(Usuarios));
        }

        
        public IActionResult DetalhesUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = _usuarioRepository.ObterUsuario(id);

            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario);
        }

        [HttpGet]
        public IActionResult ExcluirUsuario(int? id)
        {
            if (id == null)
            {
                return (NotFound());
            }
            var usuario = _usuarioRepository.ObterUsuario(id);
            if (usuario == null)
            {
                return (NotFound());
            }

            return View(usuario);
        }

        [HttpPost, ActionName("ExcluirUsuario")]
        [ValidateAntiForgeryToken]
        public IActionResult ExcluirUsuarioConfirm(int? id)
        {
            _usuarioRepository.ExcluirUsuario(id);
            return RedirectToAction(nameof(Usuarios));
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login([FromForm] Usuario usuario)
        {
            Usuario user = _usuarioRepository.VerificarLoginUsuario(usuario);
            if (user != null)
            {
                // Guardar a sessão               
                _loginUsuario.ArmazenarSessao(user);
                return RedirectToAction("AtendimentosUsuario", "Atendimento");
            }
            else
            {
                ViewData["MSG_E"] = "Usuário não encontrado! tente novamente";
                return View();
            }
        }

        [HttpGet]
        public IActionResult ConfirmPrimeiroUsuario()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Logout()
        {
            return View();
        }


        [HttpPost, ActionName("Logout")]
        public IActionResult LogoutConfirm()
        {
            _loginUsuario.RemoverSessao();
            return RedirectToAction(nameof(Login));
        }

    }
}
