﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TCCprojeto.Data;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Repositories
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public UsuarioRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AtualizarUsuario(Usuario usuario)
        {
            _dbContext.Update(usuario);
            _dbContext.SaveChanges();
        }

        public void CadastrarUsuario(Usuario usuario)
        {
            _dbContext.Add(usuario);
            _dbContext.SaveChanges();
        }

        public void ExcluirUsuario(int? id)
        {
            var usuario = ObterUsuario(id);
            _dbContext.Remove(usuario);
            _dbContext.SaveChanges();
        }

        public List<Usuario> ListarPorNome(string searchString)
        {
            var usuarios = _dbContext.Usuarios.Where(s => s.NomeUsuario.ToUpper().Contains(searchString.ToUpper()));
            return (usuarios.ToList());
        }

        public List<Usuario> ListarUsuarios()
        {
            var usuarios = _dbContext.Usuarios.Include(a => a.TipoUsuario);
            return (usuarios.ToList());
        }

        public Usuario VerificarLoginUsuario(Usuario usuario)
        {
             return(_dbContext.Usuarios.Where(m => m.Email == usuario.Email &&
            m.Senha == usuario.Senha).FirstOrDefault());
        }

        public Usuario ObterUsuario(int? id)
        {
            var usuario = _dbContext.Usuarios.Include(a => a.TipoUsuario).FirstOrDefault(a => a.IdUsuario == id);
            return (usuario);
        }
    }
}
