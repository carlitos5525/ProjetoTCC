﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TCCprojeto.Models
{
    public class Atendimento
    {
        [Key]
        public int? IdAtendimento { get; set; }
        [Display(Name = "Data de Início")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy HH:mm}")]
        public DateTime DataInicio { get; set; }
        public string Observacoes { get; set; }

        [Display(Name = "Código do Serviço")]
        public int IdTipoServico { get; set; } // Chave estrangeira
        public virtual TipoServico TipoServico { get; set; }


        [Display(Name = "Código do Cliente")]
        public int? IdCliente { get; set; } // Chave estrangeira
        public virtual Cliente Cliente { get; set; }

        [Display(Name = "Código do Usuário")]
        public int? IdUsuario { get; set; }//chave estrangeira
        public virtual Usuario Usuario { get; set; }

        [Display(Name = "Código da Empresa")]
        public int? IdEmpresa { get; set; }//chave estrangeira
        public virtual Empresa Empresa { get; set; }
    }
}
