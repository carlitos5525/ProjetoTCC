﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TCCprojeto.Data;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Repositories
{
    public class EmpresaRepository : IEmpresaRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public EmpresaRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AtualizarEmpresa(Empresa empresa)
        {
            _dbContext.Update(empresa);
            _dbContext.SaveChanges();
        }

        public void CadastrarEmpresa(Empresa empresa)
        {
            _dbContext.Add(empresa);
            _dbContext.SaveChanges();
        }

        public Empresa ObterEmpresa(int? id)
        {
            return (_dbContext.Empresas.Find(id));
        }
    }
}
