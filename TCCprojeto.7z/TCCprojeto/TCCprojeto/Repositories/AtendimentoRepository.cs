﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TCCprojeto.Data;
using TCCprojeto.Libs.Login;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Repositories
{
    public class AtendimentoRepository : IAtendimentoRepository
    {
        private readonly ApplicationDbContext _dbContext;

        private readonly LoginUsuario _loginUsuario;

        public AtendimentoRepository(ApplicationDbContext dbContext, LoginUsuario loginUsuario)
        {
            _dbContext = dbContext;
            _loginUsuario = loginUsuario;
        }

        public void AtualizarAtendimento(Atendimento atendimento)
        {
            _dbContext.Update(atendimento);
            _dbContext.SaveChanges();
        }

        public void CriarAtendimento(Atendimento atendimento)
        {
            _dbContext.Add(atendimento);
            _dbContext.SaveChanges();
        }

        public void ExcluirAtendimento(int? id)
        {
            Atendimento atendimento = ObterAtendimento(id);
            _dbContext.Remove(atendimento);
            _dbContext.SaveChanges();
        }

        public List<Atendimento> ListarAtendimentos()
        {
            Usuario usuario = _loginUsuario.GetUsuario();

            var atendimentos = _dbContext.Atendimentos.Include(a => a.TipoServico).Include(a => a.Cliente).Include(a => a.Usuario)
                .Include(a => a.Empresa);
            return (atendimentos.ToList());
        }

        public Atendimento ObterAtendimento(int? id)
        {
            return (_dbContext.Atendimentos.Find(id));
        }

        public Atendimento ObterComDetalhes(int? id)
        {
            Atendimento atendimento = _dbContext.Atendimentos.Include(a => a.Cliente).Include(a => a.TipoServico)
                .Include(a => a.Usuario).FirstOrDefault(a => a.IdAtendimento == id);
            return (atendimento);
        }

        public List<Atendimento> ListarPorNome(string searchString)
        {
            var atendimentos = ListarAtendimentos().Where(a => a.Cliente.Nome.ToUpper().Contains(searchString.ToUpper())
            || a.Usuario.NomeUsuario.ToUpper().Contains(searchString.ToUpper()));
            return (atendimentos.ToList());
        }

    }
}
