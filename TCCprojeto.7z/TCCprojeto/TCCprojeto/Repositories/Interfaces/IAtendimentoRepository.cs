﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TCCprojeto.Models;

namespace TCCprojeto.Repositories.Interfaces
{
    public interface IAtendimentoRepository
    {
        List<Atendimento> ListarAtendimentos();
        void CriarAtendimento(Atendimento atendimento);
        void AtualizarAtendimento(Atendimento atendimento);
        Atendimento ObterAtendimento(int? id);
        void ExcluirAtendimento(int? id);
        Atendimento ObterComDetalhes(int? id);
        List<Atendimento> ListarPorNome(string searchString);
    }
}
