﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TCCprojeto.Models;

namespace TCCprojeto.Repositories.Interfaces
{
    public interface IEmpresaRepository
    {
        Empresa ObterEmpresa(int? id);
        void CadastrarEmpresa(Empresa empresa);
        void AtualizarEmpresa(Empresa empresa);
    }
}
