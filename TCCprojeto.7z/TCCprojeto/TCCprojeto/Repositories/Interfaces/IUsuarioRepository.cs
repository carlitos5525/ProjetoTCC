﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TCCprojeto.Models;

namespace TCCprojeto.Repositories.Interfaces
{
    public interface IUsuarioRepository
    {
        Usuario ObterUsuario(int? id);
        List<Usuario> ListarUsuarios();
        void CadastrarUsuario(Usuario usuario);
        void AtualizarUsuario(Usuario usuario);
        void ExcluirUsuario(int? id);
        List<Usuario> ListarPorNome(string searchString);
    }
}
