﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TCCprojeto.Libs.Login;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Controllers
{
    public class UsuarioController : Controller
    {
        private IUsuarioRepository _usuarioRepository;

        private LoginUsuario _loginUsuario;

        public UsuarioController(IUsuarioRepository usuarioRepository, LoginUsuario loginUsuario)
        {
            _usuarioRepository = usuarioRepository;
            _loginUsuario = loginUsuario;
        }

        public IActionResult Usuarios(string searchString)
        {

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(_usuarioRepository.ListarPorNome(searchString));

            }
            else
            {
                return View(_usuarioRepository.ListarUsuarios());
            }

        }

        [HttpGet]
        public IActionResult CadastroUsuario()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CadastroUsuario(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                _usuarioRepository.CadastrarUsuario(usuario);
                return RedirectToAction(nameof(Usuarios));
            }

            return View(usuario);
        }

        [HttpGet]
        public IActionResult EditarUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var usuario = _usuarioRepository.ObterUsuario(id);
            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarUsuario(int? id, [FromForm] Usuario usuario)
        {
            if (id != usuario.IdUsuario)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _usuarioRepository.AtualizarUsuario(usuario);
            }
            return RedirectToAction(nameof(Usuarios));
        }

        [HttpGet]
        public IActionResult DetalhesUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = _usuarioRepository.ObterUsuario(id);

            if (usuario == null)
            {
                return NotFound();
            }

            return View(usuario);
        }

        [HttpGet]
        public IActionResult ExcluirUsuario(int? id)
        {
            if (id == null)
            {
                return (NotFound());
            }
            var usuario = _usuarioRepository.ObterUsuario(id);
            if (usuario == null)
            {
                return (NotFound());
            }

            return View(usuario);
        }

        [HttpPost, ActionName("ExcluirUsuario")]
        [ValidateAntiForgeryToken]
        public IActionResult ExcluirUsuarioConfirm(int? id)
        {
            _usuarioRepository.ExcluirUsuario(id);
            return RedirectToAction(nameof(Usuarios));
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login([FromForm] Usuario usuario)
        {
            Usuario user = _usuarioRepository.VerificarLoginUsuario(usuario);
            if (user != null)
            {
                // Guardar a sessão               
                _loginUsuario.ArmazenarSessao(user);
                return RedirectToAction(nameof(AtendimentoController.Atendimentos));
            }
            else
            {
                ViewData["MSG_E"] = "Usuário não encontrado! tente novamente";
                return View();
            }
            
        }

    }
}
