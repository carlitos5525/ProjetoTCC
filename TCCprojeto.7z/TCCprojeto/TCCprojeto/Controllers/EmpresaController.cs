﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Controllers
{
    public class EmpresaController : Controller
    {
        private readonly IEmpresaRepository _empresaRepository;

        public EmpresaController(IEmpresaRepository empresaRepository)
        {
            _empresaRepository = empresaRepository;
        }

        [HttpGet]
        public IActionResult CadastrarEmpresa()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CadastrarEmpresa(Empresa empresa)
        {
            _empresaRepository.CadastrarEmpresa(empresa);
            return RedirectToAction("CadastroPrimeiroUsuario", "Usuario", empresa);
        }

        [HttpGet]
        public IActionResult EditarEmpresa(int? id)
        {
            var empresa = _empresaRepository.ObterEmpresa(id);
            return View(empresa);
        }

        [HttpPost]
        public IActionResult EditarEmpresa([FromForm] Empresa empresa)
        {
            if (ModelState.IsValid)
            {
                _empresaRepository.AtualizarEmpresa(empresa);
            }
            return View("DetalhesEmpresa", empresa);
        }

        [HttpGet]
        public IActionResult DetalhesEmpresa(Empresa empresa)
        {
            return View(empresa);
        }
    }
}
