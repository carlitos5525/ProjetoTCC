﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TCCprojeto.Models;
using System.Security;
using System.Transactions;
using TCCprojeto.Libs.Sessao;


namespace TCCprojeto.Libs.Login
{
    public class LoginUsuario
    {
        private string key = "Login.Usuario";
        private Sessao.Sessao _sessao;

        public LoginUsuario(Sessao.Sessao sessao)
        {
            _sessao = sessao;
        }
        // Precisa serializar os dados 
        // Converter de Objeto para Json.
        public void ArmazenarSessao(Usuario usuario)
        {
            string usuarioJSONStr = JsonConvert.SerializeObject(usuario);
            _sessao.Cadastrar(key, usuarioJSONStr);
        }
        // Precisa Deserializar os dados 
        // Converter de String JSON para Obj.
        public Usuario GetUsuario()
        {
            if (_sessao.Existe(key))
            {
                string usuarioJSONStr = _sessao.Consultar(key);
                return JsonConvert.DeserializeObject<Usuario>(usuarioJSONStr);
            }
            else
            {
                return null;
            }
        }
    }
}
