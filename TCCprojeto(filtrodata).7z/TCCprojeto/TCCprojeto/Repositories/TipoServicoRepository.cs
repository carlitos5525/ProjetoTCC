﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TCCprojeto.Data;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Repositories
{
    public class TipoServicoRepository : ITipoServicoRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public TipoServicoRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AtualizarServico(TipoServico tipoServico)
        {
            _dbContext.Update(tipoServico);
            _dbContext.SaveChanges();
        }

        public void CadastrarServico(TipoServico tipoServico)
        {
            _dbContext.Add(tipoServico);
            _dbContext.SaveChanges();
        }

        public void ExcluirServico(int? id)
        {
            var servico = ObterServico(id);
            _dbContext.Remove(servico);
            _dbContext.SaveChanges();
        }

        public List<TipoServico> ListarPorNome(string searchString)
        {
            var servicos = _dbContext.TipoServicos.Where(s => s.NomeServico.ToUpper().Contains(searchString.ToUpper()));
            return (servicos.ToList());
        }

        public List<TipoServico> ListarServicos()
        {
            return (_dbContext.TipoServicos.ToList());
        }

        public TipoServico ObterServico(int? id)
        {
            return (_dbContext.TipoServicos.Find(id));
        }
    }
}
