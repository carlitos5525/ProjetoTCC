﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TCCprojeto.Migrations
{
    public partial class tipousuario : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "IdTipoUsuario",
                table: "Usuarios",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "Concluido",
                table: "Atendimentos",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "TipoUsuarios",
                columns: table => new
                {
                    IdTipoUsuario = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    NomeTipoUsuario = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TipoUsuarios", x => x.IdTipoUsuario);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Usuarios_IdTipoUsuario",
                table: "Usuarios",
                column: "IdTipoUsuario");

            migrationBuilder.AddForeignKey(
                name: "FK_Usuarios_TipoUsuarios_IdTipoUsuario",
                table: "Usuarios",
                column: "IdTipoUsuario",
                principalTable: "TipoUsuarios",
                principalColumn: "IdTipoUsuario",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Usuarios_TipoUsuarios_IdTipoUsuario",
                table: "Usuarios");

            migrationBuilder.DropTable(
                name: "TipoUsuarios");

            migrationBuilder.DropIndex(
                name: "IX_Usuarios_IdTipoUsuario",
                table: "Usuarios");

            migrationBuilder.DropColumn(
                name: "IdTipoUsuario",
                table: "Usuarios");

            migrationBuilder.DropColumn(
                name: "Concluido",
                table: "Atendimentos");
        }
    }
}
