﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TCCprojeto.Data;
using TCCprojeto.Libs.Login;
using TCCprojeto.Models;
using TCCprojeto.Repositories.Interfaces;

namespace TCCprojeto.Controllers
{
    public class AtendimentoController : Controller
    {
        private readonly IAtendimentoRepository _atendimentoRepository;

        private readonly ApplicationDbContext _dbcontext;

        private readonly LoginUsuario _loginUsuario;


        public AtendimentoController(IAtendimentoRepository atendimentoRepository, ApplicationDbContext applicationDbContext,
            LoginUsuario loginUsuario)
        {
            _atendimentoRepository = atendimentoRepository;
            _dbcontext = applicationDbContext;
            _loginUsuario = loginUsuario;
        }

        public IActionResult Atendimentos(string sortOrder, string searchString, DateTime? FromDate, DateTime? ToDate)
        {
            ViewBag.ClienteParam = String.IsNullOrEmpty(sortOrder) ? "Cliente" : "";
            ViewBag.UsuarioParam = String.IsNullOrEmpty(sortOrder) ? "Usuario" : "";
            ViewBag.ServicoParam = String.IsNullOrEmpty(sortOrder) ? "Servico" : "";
            ViewBag.DataParam = String.IsNullOrEmpty(sortOrder) ? "Data" : "";
            Usuario usuario = _loginUsuario.GetUsuario();
            
            var atendimentos = _atendimentoRepository.ListarAtendimentos().Where(a => a.IdEmpresa == usuario.IdEmpresa && a.Concluido == false)
                .OrderBy(d => d.DataInicio);

            if (sortOrder == "Cliente")
            {
                return View(atendimentos.OrderBy(n => n.Cliente.Nome));
            }

            if(sortOrder == "Usuario")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if(sortOrder == "Servico")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Data")
            {
                return View(atendimentos.OrderByDescending(n => n.DataInicio.Date));
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(atendimentos.Where(a => a.Cliente.Nome.ToUpper().Contains(searchString.ToUpper())
            || a.Usuario.NomeUsuario.ToUpper().Contains(searchString.ToUpper())));
            }

            if(FromDate != null && ToDate != null)
            {
                return View(atendimentos.Where(m => m.DataInicio >= FromDate && m.DataInicio <= ToDate));
            }

            else
            {
                return View(atendimentos);
            }
        }

        public IActionResult AtendimentosConcluidos(string sortOrder, string searchString, DateTime? FromDate, DateTime? ToDate)
        {
            Usuario user = _loginUsuario.GetUsuario();
            var atendimentos = _atendimentoRepository.ListarAtendimentos().Where(a => a.Concluido == true
                && a.IdEmpresa == user.IdEmpresa);

            ViewBag.ClienteParam = String.IsNullOrEmpty(sortOrder) ? "Cliente" : "";
            ViewBag.UsuarioParam = String.IsNullOrEmpty(sortOrder) ? "Usuario" : "";
            ViewBag.ServicoParam = String.IsNullOrEmpty(sortOrder) ? "Servico" : "";
            ViewBag.DataParam = String.IsNullOrEmpty(sortOrder) ? "Data" : "";



            if (sortOrder == "Cliente")
            {
                return View(atendimentos.OrderBy(n => n.Cliente.Nome));
            }

            if (sortOrder == "Usuario")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Servico")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Data")
            {
                return View(atendimentos.OrderByDescending(n => n.DataInicio.Date));
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(atendimentos.Where(a => a.Cliente.Nome.ToUpper().Contains(searchString.ToUpper())
            || a.Usuario.NomeUsuario.ToUpper().Contains(searchString.ToUpper())));
            }

            if (FromDate != null && ToDate != null)
            {
                return View(atendimentos.Where(m => m.DataInicio >= FromDate && m.DataInicio <= ToDate));
            }

            else
            {
                return View(atendimentos);
            }
        }

        [HttpGet]
        public IActionResult CriarAtendimento()
        {
            Usuario user = _loginUsuario.GetUsuario();
            // Para preencher a dropdownList
            // Utiliza-se o ViewData para passar os nomes dos fabricntes para a view de Cadastro de Carros
            ViewData["IdUsuario"] = new SelectList(_dbcontext.Usuarios.Where(a => a.IdEmpresa == user.IdEmpresa), "IdUsuario", "NomeUsuario");
            ViewData["IdCliente"] = new SelectList(_dbcontext.Clientes.Where(a => a.IdEmpresa == user.IdEmpresa), "IdCliente", "Nome");
            ViewData["IdTipoServico"] = new SelectList(_dbcontext.TipoServicos.Where(a => a.IdEmpresa == user.IdEmpresa), "IdTipoServico", "NomeServico");
            return View();
        }

        [HttpPost]
        public IActionResult CriarAtendimento(Atendimento atendimento)
        {
            Usuario usuario = _loginUsuario.GetUsuario();
            if (ModelState.IsValid)
            {
                atendimento.IdEmpresa = usuario.IdEmpresa;
                _atendimentoRepository.CriarAtendimento(atendimento);
                return RedirectToAction(nameof(Atendimentos));
            }
            return View(atendimento);
        }

        [HttpGet]
        public IActionResult EditarAtendimento(int? id)
        {
            Usuario user = _loginUsuario.GetUsuario();

            if (id == null)
            {
                return NotFound();
            }
            var atendimento = _atendimentoRepository.ObterAtendimento(id);
            if (atendimento == null)
            {
                return NotFound();
            }
            // Para preencher a dropdownList
            // Utiliza-se o ViewData para passar os nomes dos fabricntes para a view de Edição de Atendimentos
            ViewData["IdTipoServico"] = new SelectList(_dbcontext.TipoServicos.Where(a => a.IdEmpresa == user.IdEmpresa), "IdTipoServico", "NomeServico");
            ViewData["IdCliente"] = new SelectList(_dbcontext.Clientes.Where(a => a.IdEmpresa == user.IdEmpresa), "IdCliente", "Nome");
            ViewData["IdUsuario"] = new SelectList(_dbcontext.Usuarios.Where(a => a.IdEmpresa == user.IdEmpresa), "IdUsuario", "NomeUsuario");

            return View(atendimento);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarAtendimento(int? id, [FromForm] Atendimento atendimento)
        {
            if (id != atendimento.IdAtendimento)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                var user = _loginUsuario.GetUsuario();
                atendimento.IdEmpresa = user.IdEmpresa;
                _atendimentoRepository.AtualizarAtendimento(atendimento);
            }

            return RedirectToAction(nameof(Atendimentos));
        }

        public IActionResult DetalhesAtendimento(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var atendimento = _atendimentoRepository.ObterComDetalhes(id);

            if (atendimento == null)
            {
                return NotFound();
            }

            return View(atendimento);
        }

        [HttpGet]
        public ActionResult DeletarAtendimento(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var atendimento = _atendimentoRepository.ObterComDetalhes(id);
            if (atendimento == null)
            {
                return NotFound();
            }
            return View(atendimento);
        }

        [HttpPost, ActionName("DeletarAtendimento")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletarAtendimentoConfir(int? id)
        {
            _atendimentoRepository.ExcluirAtendimento(id);
            return RedirectToAction(nameof(Atendimentos));
        }

        //[HttpGet]
        public IActionResult AtendimentosUsuario(String searchString, String sortOrder, DateTime? FromDate, DateTime? ToDate)
        {
            ViewBag.ClienteParam = String.IsNullOrEmpty(sortOrder) ? "Cliente" : "";
            ViewBag.ServicoParam = String.IsNullOrEmpty(sortOrder) ? "Servico" : "";
            ViewBag.DataParam = String.IsNullOrEmpty(sortOrder) ? "Data" : "";

            Usuario usuario = _loginUsuario.GetUsuario();
            var atendimentos = _atendimentoRepository.ListarAtendimentos().Where(a => a.Usuario.IdUsuario == usuario.IdUsuario
            && a.Empresa.IdEmpresa == usuario.IdEmpresa && a.Concluido == false).OrderBy(d => d.DataInicio);
           
            if (sortOrder == "Cliente")
            {
                return View(atendimentos.OrderBy(n => n.Cliente.Nome));
            }

            if (sortOrder == "Servico")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Data")
            {
                return View(atendimentos.OrderByDescending(n => n.DataInicio.Date));
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(atendimentos.Where(a => a.Cliente.Nome.ToUpper().Contains(searchString.ToUpper())));
            }

            if (FromDate != null && ToDate != null)
            {
                return View(atendimentos.Where(m => m.DataInicio >= FromDate && m.DataInicio <= ToDate));
            }

            else
            {
                return View(atendimentos);
            }

        }

        public IActionResult AtendimentosConcluidosUsuario(string sortOrder, string searchString, DateTime? FromDate, DateTime? ToDate)
        {
            Usuario user = _loginUsuario.GetUsuario();
            var atendimentos = _atendimentoRepository.ListarAtendimentos().Where(a => a.Concluido == true
                && a.IdEmpresa == user.IdEmpresa && a.IdUsuario == user.IdUsuario);

            ViewBag.ClienteParam = String.IsNullOrEmpty(sortOrder) ? "Cliente" : "";
            ViewBag.UsuarioParam = String.IsNullOrEmpty(sortOrder) ? "Usuario" : "";
            ViewBag.ServicoParam = String.IsNullOrEmpty(sortOrder) ? "Servico" : "";
            ViewBag.DataParam = String.IsNullOrEmpty(sortOrder) ? "Data" : "";



            if (sortOrder == "Cliente")
            {
                return View(atendimentos.OrderBy(n => n.Cliente.Nome));
            }

            if (sortOrder == "Usuario")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Servico")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Data")
            {
                return View(atendimentos.OrderByDescending(n => n.DataInicio.Date));
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(atendimentos.Where(a => a.Cliente.Nome.ToUpper().Contains(searchString.ToUpper())
            || a.Usuario.NomeUsuario.ToUpper().Contains(searchString.ToUpper())));
            }

            if (FromDate != null && ToDate != null)
            {
                return View(atendimentos.Where(m => m.DataInicio >= FromDate && m.DataInicio <= ToDate));
            }

            else
            {
                return View(atendimentos);
            }
        }



        [HttpGet]
        public IActionResult CriarAtendimentoUsuario()
        {
            Usuario user = _loginUsuario.GetUsuario();

            // Para preencher a dropdownList
            // Utiliza-se o ViewData para passar os nomes dos fabricntes para a view de Cadastro de Carros
            // ViewData["IdUsuario"] = _loginUsuario.GetUsuario();
            ViewData["IdCliente"] = new SelectList(_dbcontext.Clientes.Where(a => a.IdEmpresa == user.IdEmpresa), "IdCliente", "Nome");
            ViewData["IdTipoServico"] = new SelectList(_dbcontext.TipoServicos.Where(a => a.IdEmpresa == user.IdEmpresa), "IdTipoServico", "NomeServico");
            return View();
        }

        [HttpPost]
        public IActionResult CriarAtendimentoUsuario(Atendimento atendimento)
        {
            Usuario usuario = _loginUsuario.GetUsuario();
            if (ModelState.IsValid)
            {
                atendimento.IdEmpresa = usuario.IdEmpresa;
                atendimento.IdUsuario = usuario.IdUsuario;
                _atendimentoRepository.CriarAtendimento(atendimento);
                return RedirectToAction(nameof(AtendimentosUsuario));
            }
            return View(atendimento);
        }

        [HttpGet]
        public IActionResult EditarAtendimentoUsuario(int? id)
        {
            Usuario user = _loginUsuario.GetUsuario();

            if (id == null)
            {
                return NotFound();
            }
            var atendimento = _atendimentoRepository.ObterAtendimento(id);
            if (atendimento == null)
            {
                return NotFound();
            }
            // Para preencher a dropdownList
            // Utiliza-se o ViewData para passar os nomes dos fabricntes para a view de Edição de Atendimentos
            ViewData["IdTipoServico"] = new SelectList(_dbcontext.TipoServicos.Where(a => a.IdEmpresa == user.IdEmpresa), "IdTipoServico", "NomeServico");
            ViewData["IdCliente"] = new SelectList(_dbcontext.Clientes.Where(a => a.IdEmpresa == user.IdEmpresa), "IdCliente", "Nome");
            

            return View(atendimento);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarAtendimentoUsuario(int? id, [FromForm] Atendimento atendimento)
        {
            if (id != atendimento.IdAtendimento)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                var user = _loginUsuario.GetUsuario();
                atendimento.IdEmpresa = user.IdEmpresa;
                atendimento.IdUsuario = user.IdUsuario;
                _atendimentoRepository.AtualizarAtendimento(atendimento);
            }

            return RedirectToAction(nameof(AtendimentosUsuario));
        }

        public IActionResult DetalhesAtendimentoUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var atendimento = _atendimentoRepository.ObterComDetalhes(id);

            if (atendimento == null)
            {
                return NotFound();
            }

            return View(atendimento);
        }

        [HttpGet]
        public ActionResult DeletarAtendimentoUsuario(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var atendimento = _atendimentoRepository.ObterComDetalhes(id);
            if (atendimento == null)
            {
                return NotFound();
            }
            return View(atendimento);
        }

        [HttpPost, ActionName("DeletarAtendimentoUsuario")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletarAtendimentoUsuarioConfir(int? id)
        {
            _atendimentoRepository.ExcluirAtendimento(id);
            return RedirectToAction(nameof(AtendimentosUsuario));
        }

        public IActionResult AtendimentosHoje(String searchString, String sortOrder)
        {
            ViewBag.ClienteParam = String.IsNullOrEmpty(sortOrder) ? "Cliente" : "";
            ViewBag.ServicoParam = String.IsNullOrEmpty(sortOrder) ? "Servico" : "";
            ViewBag.DataParam = String.IsNullOrEmpty(sortOrder) ? "Data" : "";

            DateTime Inicio = DateTime.Today;
            DateTime Final = DateTime.Today;

            Usuario usuario = _loginUsuario.GetUsuario();
            var atendimentos = _atendimentoRepository.ListarAtendimentos().Where(a => a.Empresa.IdEmpresa == usuario.IdEmpresa
            && a.DataInicio.Date == DateTime.Today && a.Concluido == false);

            if (sortOrder == "Cliente")
            {
                return View(atendimentos.OrderBy(n => n.Cliente.Nome));
            }

            if (sortOrder == "Servico")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Data")
            {
                return View(atendimentos.OrderByDescending(n => n.DataInicio.Date));
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(atendimentos.Where(a => a.Cliente.Nome.ToUpper().Contains(searchString.ToUpper())));
            }

            else
            {
                return View(atendimentos);
            }

        }

        public IActionResult AtendimentosConcluidosHoje(string sortOrder, string searchString)
        {
            Usuario user = _loginUsuario.GetUsuario();
            var atendimentos = _atendimentoRepository.ListarAtendimentos().Where(a => a.Concluido == true
                && a.DataInicio.Date == DateTime.Today && a.Empresa.IdEmpresa == user.IdEmpresa);

            ViewBag.ClienteParam = String.IsNullOrEmpty(sortOrder) ? "Cliente" : "";
            ViewBag.UsuarioParam = String.IsNullOrEmpty(sortOrder) ? "Usuario" : "";
            ViewBag.ServicoParam = String.IsNullOrEmpty(sortOrder) ? "Servico" : "";
            ViewBag.DataParam = String.IsNullOrEmpty(sortOrder) ? "Data" : "";



            if (sortOrder == "Cliente")
            {
                return View(atendimentos.OrderBy(n => n.Cliente.Nome));
            }

            if (sortOrder == "Usuario")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Servico")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Data")
            {
                return View(atendimentos.OrderByDescending(n => n.DataInicio.Date));
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(atendimentos.Where(a => a.Cliente.Nome.ToUpper().Contains(searchString.ToUpper())
            || a.Usuario.NomeUsuario.ToUpper().Contains(searchString.ToUpper())));
            }

            else
            {
                return View(atendimentos);
            }
        }

        public IActionResult AtendimentosUsuarioHoje(String searchString, String sortOrder)
        {
            ViewBag.ClienteParam = String.IsNullOrEmpty(sortOrder) ? "Cliente" : "";
            ViewBag.ServicoParam = String.IsNullOrEmpty(sortOrder) ? "Servico" : "";
            ViewBag.DataParam = String.IsNullOrEmpty(sortOrder) ? "Data" : "";

            DateTime Inicio = DateTime.Today;
            DateTime Final = DateTime.Today;

            Usuario usuario = _loginUsuario.GetUsuario();
            var atendimentos = _atendimentoRepository.ListarAtendimentos().Where(a => a.Empresa.IdEmpresa == usuario.IdEmpresa
            && a.DataInicio.Date == DateTime.Today && a.IdUsuario == usuario.IdUsuario && a.Concluido == false);

            if (sortOrder == "Cliente")
            {
                return View(atendimentos.OrderBy(n => n.Cliente.Nome));
            }

            if (sortOrder == "Servico")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Data")
            {
                return View(atendimentos.OrderByDescending(n => n.DataInicio.Date));
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(atendimentos.Where(a => a.Cliente.Nome.ToUpper().Contains(searchString.ToUpper())));
            }

            else
            {
                return View(atendimentos);
            }

        }

        public IActionResult AtendimentosConcluidosUsuarioHoje(string sortOrder, string searchString)
        {
            Usuario user = _loginUsuario.GetUsuario();
            var atendimentos = _atendimentoRepository.ListarAtendimentos().Where(a => a.Concluido == true
                && a.DataInicio.Date == DateTime.Today && a.Empresa.IdEmpresa == user.IdEmpresa && a.IdUsuario == user.IdUsuario);

            ViewBag.ClienteParam = String.IsNullOrEmpty(sortOrder) ? "Cliente" : "";
            ViewBag.UsuarioParam = String.IsNullOrEmpty(sortOrder) ? "Usuario" : "";
            ViewBag.ServicoParam = String.IsNullOrEmpty(sortOrder) ? "Servico" : "";
            ViewBag.DataParam = String.IsNullOrEmpty(sortOrder) ? "Data" : "";



            if (sortOrder == "Cliente")
            {
                return View(atendimentos.OrderBy(n => n.Cliente.Nome));
            }

            if (sortOrder == "Usuario")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Servico")
            {
                return View(atendimentos.OrderBy(n => n.Usuario.NomeUsuario));
            }

            if (sortOrder == "Data")
            {
                return View(atendimentos.OrderByDescending(n => n.DataInicio.Date));
            }

            if (!String.IsNullOrEmpty(searchString))
            {
                return View(atendimentos.Where(a => a.Cliente.Nome.ToUpper().Contains(searchString.ToUpper())
            || a.Usuario.NomeUsuario.ToUpper().Contains(searchString.ToUpper())));
            }

            else
            {
                return View(atendimentos);
            }
        }
    }
}
