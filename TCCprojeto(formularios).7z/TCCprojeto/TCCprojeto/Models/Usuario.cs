﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TCCprojeto.Models
{
    public class Usuario
    {
        [Key]
        public int? IdUsuario { get; set; }
        [Display(Name = "Nome do Funcionário")]
        [Required]
        public string NomeUsuario { get; set; }
        [Display(Name = "E-mail")]
        [Required]
        public string Email { get; set; }
        [Required]
        public string Senha { get; set; }

        public virtual ICollection<Atendimento> Atendimentos { get; set; }

        [Display(Name = "Código da Empresa")]
        public int? IdEmpresa { get; set; }//chave estrangeira
        public virtual Empresa Empresa { get; set; }

        [Display(Name = "Tipo do Usuário")]
        public int? IdTipoUsuario { get; set; }//chave estrangeira
        public virtual TipoUsuario TipoUsuario { get; set; }
    }
}
