﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TCCprojeto.Models
{
    public class Empresa
    {
        [Key]
        public int? IdEmpresa { get; set; }
        [Display(Name = "Empresa")]
        public string NomeEmpresa { get; set; }
        public int CNPJ { get; set; }
        public String Telefone { get; set; }

        public virtual ICollection<Atendimento> Atendimentos { get; set; }
        public virtual ICollection<TipoServico> TipoServicos { get; set; }
        public virtual ICollection<Cliente> Clientes { get; set; }
        public virtual ICollection<Usuario> Usuarios { get; set; }
    }
}
